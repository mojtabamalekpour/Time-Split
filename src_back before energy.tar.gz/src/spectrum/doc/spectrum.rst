.. include:: replace.txt

Spectrum model
--------------

*Placeholder chapter*

|ns3| Spectrum model support advanced spectrum modeling functionalities for the simulation of wireless networks.

The model is described in [Baldo2009]_. 

..
  Reference Baldo2009 is defined in lte/doc/lte-references.rst

